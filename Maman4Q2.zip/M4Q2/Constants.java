
import java.nio.file.Path;

//Represents Constants that the program uses
public class Constants {

   //the file path that user selected
    public static Path FILE_PATH;
}
